<?php

namespace App\Http\Controllers;

use App\User;
use Illuminate\Http\Request;
use Charts;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Input;

class estadisticasController extends Controller
{
    public function index()
    {
        $tipo = Input::get('type');
        $valor=Input::get('valor');
        $chart = [];
        if ($tipo == "inventario") {
            //bar es el normal
            $usuario = Auth::user()->id;
            $datos = DB::select("call sp_estadisticas($usuario,'$valor');");
            $datos1 = [];
            $valor = [];
            foreach ($datos as $d) {
                array_push($datos1, $d->inventario);
                array_push($valor, $d->total);
            }
            $chart = Charts::multi('bar', 'highcharts')
                ->labels($datos1);
            for ($i = 0; $i < count($datos1); $i++) {
                $da = [];
                for ($j = 0; $j < count($valor); $j++) {
                    array_push($da, $valor[$i]);
                }
                $chart->dataset($datos1[$i], $da);
            }
            /*Charts::database(collect($datos), 'bar', 'highcharts')
                ->title('Estadisticas por inventario')
                ->dimensions(1080, 500)
                ->responsive(true)
                ->elementLabel("Inventario")
                ->groupBy("inventario")
                ->groupByMonth(date('Y'), true);;*/
            //->groupByMonth(date('Y'), true);
        } elseif ($tipo == "producto") {
            $datos = DB::select("call sp_inventarioproductos();");
            $chart = Charts::database(collect($datos), 'bar', 'highcharts')
                ->title('Estadisticas por inventario')
                ->dimensions(1080, 500)
                ->responsive(true)
                ->elementLabel("Producto", "total")
                ->groupBy("producto")
                ->groupByMonth(date('Y'), true);;
            //->groupByMonth(date('Y'), true);
        }
        return view('home.estadisticas.estadistica', ['chart' => $chart]);
    }
}
