<?php

namespace App\Notifications;

use Carbon\Carbon;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Broadcasting\ShouldBroadcast;
use Illuminate\Notifications\Notification;
use Illuminate\Contracts\Queue\ShouldQueue;
use NotificationChannels\WebPush\WebPushMessage;
use NotificationChannels\WebPush\WebPushChannel;

class Notificaciones extends Notification implements ShouldQueue
{
    use Queueable;
    public $notificacion;

    /**
     * Create a new notification instance.
     *
     * @return void
     */
    public function __construct($notificacion)
    {
        //
        $this->notificacion = $notificacion;
    }

    /**
     * Get the notification's delivery channels.
     *
     * @param  mixed $notifiable
     * @return array
     */
    public function via($notifiable)
    {
        return ['database', 'broadcast', WebPushChannel::class];
    }

    /**
     * Get the array representation of the notification.
     *
     * @param  mixed $notifiable
     * @return array
     */
    public function toArray($notifiable)
    {
        return [
            'titulo' => $this->notificacion['titulo'],
            'mensaje' => $this->notificacion['mensaje'],
            'url' => $this->notificacion['url'],
            'creada' => Carbon::now()->toIso8601String()
        ];
    }

    /**
     * Get the web push representation of the notification.
     *
     * @param  mixed $notifiable
     * @param  mixed $notification
     * @return \Illuminate\Notifications\Messages\DatabaseMessage
     */
    public function toWebPush($notifiable, $notification)
    {
        return WebPushMessage::create()
            //->id($notification->id)
            ->title( $this->notificacion['titulo'])
            ->icon('https://2.bp.blogspot.com/-S7x7EWRHr-c/VxofBUlNqBI/AAAAAAAAAfE/mqUao7feYTsrOMLfaV1COEB3ycnguslOgCLcB/s1600/bell-1096280_960_720.png')
            ->body($this->notificacion['mensaje'])
            ->action('Restaurante.com', $this->notificacion['url']);
    }
}
