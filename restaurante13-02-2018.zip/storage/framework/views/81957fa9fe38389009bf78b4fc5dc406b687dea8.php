<?php
/**
 * Created by PhpStorm.
 * User: windows 8.1
 * Date: 08/02/2018
 * Time: 5:33 PM
 */
?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1 class="center">Su pedido ya se encuentra listo!

        </h1>
        <div class="center">
            <img src="<?php echo e(asset('img/megusta.gif')); ?>" width="200" height="200">

        </div>
        <div class="center">
            <a href="<?php echo e(url('cliente')); ?>" class="btn light light-blue"><span class="glyphicon glyphicon-home"></span>Atras</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.cliente', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>