<?php
/**
 * Created by PhpStorm.
 * User: windows 8.1
 * Date: 23/01/2018
 * Time: 10:37 AM
 */
?>

<?php $__env->startSection('content'); ?>
    <div class="jumbotron">
        <div class="row">
            <fieldset>
                <legend>Listado de mesas</legend>
                <button class="btn light light-blue right botonnuevamesa" type="button" data-toggle="modal"
                        data-target="#nuevamesa">Agregar mesa
                </button>
                <table class="table-responsive table-hover container responsive-table" style="max-width: 100%">
                    <thead>
                    <tr>
                        <th>
                            Nombre
                        </th>
                        <th>
                            Descripción
                        </th>
                        <th>
                            Mesero
                        </th>
                        <th>
                            Qr Code
                        </th>
                        <th>
                            Gestionar
                        </th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $datos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr id="tr<?php echo e($item->mesaid); ?>">
                            <td>
                                <?php echo e($item->nombre); ?>

                            </td>
                            <td>
                                <?php echo e($item->descripcion); ?>

                            </td>
                            <td>
                                <select class="selectmesero" name="mesero<?php echo e($item->mesaid); ?>"
                                        id="mesero<?php echo e($item->mesaid); ?>">
                                    <option value="">Seleccione...</option>
                                    <option value="<?php echo e($item->id); ?>" selected><?php echo e($item->text); ?></option>
                                </select>
                            </td>
                            <td>
                                <a href="<?php echo e(url('descargarqrcode').'?file='.$item->qrimagen.'&nombre='.$item->nombre); ?>">
                                    <img src="<?php echo e($item->qrimagen); ?>" width="50" height="50">
                                </a>

                            </td>
                            <td>
                                <a href="#!" onclick="abrirpopat('<?php echo e($item->mesaid); ?>')"><span
                                            class="glyphicon glyphicon-remove-circle red-text center"></span></a>
                                &nbsp;&nbsp;&nbsp;
                                <a href="#!" onclick="actualizarmesa('<?php echo e($item->id); ?>','<?php echo e($item->mesaid); ?>')"><span
                                            class="glyphicon glyphicon-floppy-save red-text center"></span></a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </fieldset>
            <div id="nuevamesa" class="modal fade" role="dialog">
                <div class="modal-dialog">

                    <!-- Modal content-->
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close"
                                    data-dismiss="modal">&times;</button>
                            <h4 class="modal-title blue-text">Nueva mesa</h4>
                        </div>
                        <div class="modal-body">
                            <div class="row">
                                <form id="formnuevamesa" action="<?php echo e(url('mesaguardar')); ?>" method="post" role="form"
                                      novalidate>
                                    <?php echo e(csrf_field()); ?>

                                    <?php if($errors->any()): ?>
                                        <div class="alert alert-danger">
                                            <ul>
                                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li><?php echo e($error); ?></li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                        </div>
                                    <?php endif; ?>
                                    <div class="input-field col s12 m6 l6">
                                        <input type="text" name="nombre" value="<?php echo e(old('nombre')); ?>" id="nombre"
                                               maxlength="100" required>
                                        <label class="active" for="nombre">Nombre de la mesa:</label>
                                    </div>
                                    <div class="col s12 m6 l6">
                                        <select name="mesero" id="mesero" class="required selectmesero" required>
                                            <option value="">Seleccione...</option>
                                        </select>
                                    </div>
                                    <div class="input-field col s12 m12 l12">
                                    <textarea class="materialize-textarea" name="descripcion" id="descripcion" required>
<?php echo e(old('descripcion')); ?>

                                    </textarea>
                                        <label for="descripcion" class="active">Descripción de la mesa:</label>
                                    </div>
                                    <div class="col s12 m12 l12 center">
                                        <button type="submit"
                                                class="btn btn-default light-blue red">
                                            Guardar
                                        </button>
                                    </div>
                                </form>
                            </div>

                        </div>
                        <div class="modal-footer">
                            <button type="button"
                                    class="btn btn-default light-blue light-green cancelarnuevamesa"
                                    data-dismiss="modal">
                                Cancelar
                            </button>
                        </div>
                    </div>

                </div>
            </div>
            <button type="button" id="eliminarmesa" style="display: none" class="btn btn-primary" data-toggle="modal"
                    data-target="#eliminardato">
                Launch demo modal
            </button>

        </div>
        <div class="row">

        </div>
        <div class="row">

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>

    <script type="text/javascript">
        var eliminarmesa = 0;
        $(document).ready(function () {
            validarformulario('formnuevamesa', {nombre: 'required', descripcion: 'required', mesero: 'required'});
            $(".botoneliminardato").click(function () {
                $.post('/mesaseliminar/' + eliminarmesa, {"_token": _to}, function (data) {
                    if (data == "OK") {
                        Materialize.toast('Mesa eliminada.', 4000);
                        $("#tr" + eliminarmesa).remove();
                    }
                    else
                        Materialize.toast(data, 4000);

                    $("#cancelareliminar").click();
                }).fail(function (error) {
                    Materialize.toast('Error::..' + error.responseText, 4000);
                });
            });
            $(".selectmesero").select2({
                // Activamos la opcion "Tags" del plugin
                /*tags: true,
                 tokenSeparators: [",", " "],*/
                ajax: {
                    dataType: 'json',
                    url: "/cargarcombos",
                    delay: 250,
                    data: function (params) {
                        return {
                            buscar: '<?php echo e(\Illuminate\Support\Facades\Auth::user()->id); ?>',
                            _token: _to,
                            op: 'cargarmesero'
                        }
                    },
                    processResults: function (data, page) {
                        return {
                            results: data
                        };
                    }
                },
                maximumInputLength: 0,
                //minimumResultsForSearch: Infinity,
                theme: 'bootstrap',
                placeholder: 'Seleccione...',
                language: "es",
                allowClear: true,
                width: '100%'
            });
            if ('<?php echo e($errors->any()); ?>') {
                $(".botonnuevamesa").click();
            }
        });
        function abrirpopat(id) {
            eliminarmesa = id;
            var popat = $("#eliminardato");
            popat.find('.tituloeliminardato').html('Eliminar mesa');
            popat.find('.textoelimardato').html('Desea eliminar la mesa seleccionada?');
            $("#eliminarmesa").click();
        }
        function actualizarmesa(id, mesaid) {
            mesero = $("#mesero" + mesaid).select2("val");
            $.post('/mesaactualizar', {"_token": _to, 'mesero': mesero, "mesaid": mesaid}, function (data) {
                if (data) {
                    Materialize.toast('Mesa actualizada.', 4000);
                }
                else
                    Materialize.toast(data, 4000);
            }).fail(function (error) {
                Materialize.toast('Error::..' + error.responseText, 4000);
            })
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>