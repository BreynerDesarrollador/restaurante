<div id="divlogin">
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-default" id="panellogin">
                    <div class="panel-heading center">Ingresar</div>

                    <div class="panel-body">
                        <form class="form-horizontal" method="POST" action="<?php echo e(route('login')); ?>">
                            <?php echo e(csrf_field()); ?>


                            <div class="form-group input-field col s12 m10 l10<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                                <label for="email" class="active grey-text">E-Mail:</label>
                                <input id="email" type="email" placeholder="Ej: example@domain.com"
                                       class="form-control white" name="email" value="<?php echo e(old('email')); ?>"
                                       required
                                       autofocus>

                                <?php if($errors->has('email')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>

                            <div class="form-group input-field col s12 m10 l10<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                                <label for="password" class="active grey-text">Contraseña:</label>

                                <input id="password" type="password" class="form-control white" name="password"
                                       required>
                                <?php if($errors->has('password')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>

                            <div class="form-group col s12 m12 l12 left-align">
                                <input type="checkbox" id="remember" class="grey-text"
                                       name="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
                                <label for="remember" class="grey-text">Recordarme</label>
                            </div>

                            <div class=" col s12 m12 l12">
                                <div class="center">
                                    <button type="submit" class="btn light light-green">
                                        Ingresar
                                    </button>
                                    <button class="btn btn-default" onclick="mostrarocultar('cancelar')">Cancelar</button>
                                    <br>

                                    <a class="btn-link blue-text" href="<?php echo e(route('password.request')); ?>">
                                        Olvidaste tu contraseña?
                                    </a>
                                    <a class="btn-link blue-text" href="<?php echo e(route('password.request')); ?>">
                                        No tienes cuenta? Registrate <strong>aquí</strong>.
                                    </a>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>