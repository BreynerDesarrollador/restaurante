<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>Restaurante.com</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/jqueryui.css')); ?>">
    <link href="<?php echo e(asset('css/select2.min.css')); ?>" rel="stylesheet"/>
    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">

    <!--Import Google Icon Font-->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <!--Import materialize.css-->
    <link type="text/css" rel="stylesheet" href="<?php echo e(asset('css/materialize.min.css')); ?>" media="screen,projection"/>

    <!--Let browser know website is optimized for mobile-->
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <meta name="description" content="Plataforma de gestión para restaurantes">
    <meta name="keywords" content="restautante, bar, etc...">
    <link href='https://fonts.googleapis.com/css?family=Lobster|Open+Sans:400,400italic,300italic,300|Raleway:300,400,600'
          rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="<?php echo e(asset('css/styleapp.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrapnotifications.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/fontawesome.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/animate.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    <link rel="stylesheet"
          href="https://cdnjs.cloudflare.com/ajax/libs/select2-bootstrap-theme/0.1.0-beta.10/select2-bootstrap.css">
    <script>
        window.Laravel = <?php echo json_encode([
            'user' => Auth::user(),
            'csrfToken' => csrf_token(),
            'vapidPublicKey' => config('webpush.vapid.public_key'),
            'pusher' => [
                'key' => config('broadcasting.connections.pusher.key'),
                'cluster' => config('broadcasting.connections.pusher.options.cluster'),
            ],
        ]); ?>;
        window.appopcion = {
            op: 'mesas'
        }
    </script>
    <script type="text/javascript" src="<?php echo e(asset('js/jquery2.1.1.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.js')); ?>"></script>
    <?php if(url()->current()==url('estadisticas')): ?>
        <?php echo Charts::assets(); ?>

    <?php endif; ?>
</head>
<body>
<div id="app" v-cloak>
    <nav class="navbar white" style="display: <?php echo e(\Illuminate\Support\Facades\Auth::check()?'block':'none'); ?>">
        <div class="container-fluid">
            <div class="navbar-header">
                <button type="button" class="blue lighten-2 white-text navbar-toggle collapsed grey-text" data-toggle="collapse"
                        data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar white"></span>
                    <span class="icon-bar white"></span>
                    <span class="icon-bar white"></span>
                </button>

                <a v-if="operacion==='mesas'" class="navbar-brand"
                   href="<?php if(\Illuminate\Support\Facades\Auth::check()): ?><?php echo e(\Illuminate\Support\Facades\Auth::user()->type==0?url('home'):url('otherhome')); ?><?php else: ?>
                           / <?php endif; ?>">Restaurante</a>
                <a v-else href="#!">otros</a>
            </div>
            <div id="navbar" class="collapse navbar-collapse">
                <ul class="nav navbar-nav navbar-right">
                    <?php if(\Illuminate\Support\Facades\Auth::check()): ?>
                        <?php if(\Illuminate\Support\Facades\Auth::user()->type==0): ?>
                            <li>
                                <div class="dropdown">
                                    <button class="btn btn-flat dropdown-toggle grey-text" type="button" id="productos"
                                            data-toggle="dropdown"><span class="glyphicon glyphicon-star"></span>
                                        Productos
                                        <span class="caret"></span></button>
                                    <ul class="dropdown-menu" role="productos" aria-labelledby="productos">
                                        <li class="dropdown-header">Gestionar productos</li>
                                        <li role="presentation"><a role="menuitem" href="<?php echo e(url('productos')); ?>"><span
                                                        class="glyphicon glyphicon-eye-open"></span>Ver
                                                productos</a></li>
                                        <!-- <li role="presentation"><a role="menuitem" href="#">Editar productos</a></li> -->
                                        <li role="presentation" class="divider"></li>
                                        <li class="dropdown-header center"></li>
                                    </ul>
                                </div>
                            </li>
                            <li>
                                <div class="dropdown">
                                    <button class="btn btn-flat dropdown-toggle grey-text" type="button" id="inventario"
                                            data-toggle="dropdown"><span class="glyphicon glyphicon-list"></span>
                                        Inventario
                                        <span class="caret"></span></button>
                                    <ul class="dropdown-menu" role="inventario" aria-labelledby="inventario">
                                        <li class="dropdown-header">Gestionar inventario</li>
                                        <li role="presentation" class="divider"></li>
                                        <li role="presentation"><a role="menuitem"
                                                                   href="<?php echo e(url('/inventario.verinventario')); ?>"><span
                                                        class="glyphicon glyphicon-eye-open"></span>Ver
                                                inventario</a></li>
                                        <li role="presentation"><a role="menuitem" href="<?php echo e(url('/inventario')); ?>"><span
                                                        class="glyphicon glyphicon-plus-sign"></span>Crear
                                                inventario</a></li>
                                        <li role="presentation" class="divider"></li>
                                        <li role="presentation"><a role="menuitem"
                                                                   href="<?php echo e(url('inventario.productos?type=1')); ?>"><span
                                                        class="glyphicon glyphicon-circle-arrow-left"></span>Inventario
                                                produtos
                                                salientes</a></li>
                                        <li role="presentation"><a role="menuitem"
                                                                   href="<?php echo e(url('inventario.productos?type=2')); ?>"><span
                                                        class="glyphicon glyphicon-circle-arrow-right"></span>Inventario
                                                produtos
                                                entrantes</a></li>
                                        <li role="presentation" class="divider"></li>
                                        <li class="dropdown-header center"></li>
                                    </ul>
                                </div>

                            <li>
                                <div class="dropdown">
                                    <button class="btn btn-flat dropdown-toggle grey-text" type="button" id="menu"
                                            data-toggle="dropdown"><span class="glyphicon glyphicon-cutlery"></span>Menú
                                        <span class="caret"></span></button>
                                    <ul class="dropdown-menu" role="menu" aria-labelledby="menu">
                                        <li class="dropdown-header">Gestionar menú</li>
                                        <li role="presentation" class="divider"></li>
                                        <li role="presentation"><a role="menuitem" href="<?php echo e(url('menu?op=menu')); ?>"><span
                                                        class="glyphicon glyphicon-plus-sign"></span>Ver menú</a></li>
                                        <li role="presentation" class="divider"></li>
                                        <li role="presentation"><a role="menuitem"
                                                                   href="<?php echo e(url('menu?op=platos')); ?>"><span
                                                        class="glyphicon glyphicon-plus-sign"></span>Ver platos</a></li>
                                        <li role="presentation"><a role="menuitem"
                                                                   href="<?php echo e(url('menu?op=bebidas')); ?>"><span
                                                        class="glyphicon glyphicon-glass"></span>Ver bebidas</a></li>
                                        <li role="presentation"><a role="menuitem"
                                                                   href="<?php echo e(url('menu?op=asociarplato')); ?>"><span
                                                        class="glyphicon glyphicon-edit"></span>Asociar plato</a></li>
                                        <li role="presentation" class="divider"></li>
                                        <li class="dropdown-header center"></li>
                                    </ul>
                                </div>
                            </li>
                            <li>
                                <a href="<?php echo e(url('estadisticas?type=inventario')); ?>" class="grey-text">
                                    <label><span class="glyphicon glyphicon-stats"></span> Estadisticas</label>
                                </a>
                            </li>
                            <li>
                                <a href="<?php echo e(url('usuarios')); ?>" class="grey-text">
                                    <label> <span class="glyphicon glyphicon-user"></span>Usuarios</label>
                                </a>
                            </li>
                            <li>
                                <a href="<?php echo e(url('mesas')); ?>" class="grey-text">
                                    <label><span class="glyphicon glyphicon-star"></span>Mesas</label>
                                </a>
                            </li>
                        <?php elseif(\Illuminate\Support\Facades\Auth::user()->type===3): ?>
                        <!--  <li>
                                <a href="#!">
                                    Pedidos
                                </a>
                            </li>
                            <li>
                                <a href="#!">
                                    Pedidos pendientes
                                </a>
                            </li> -->
                        <?php endif; ?>
                        <li>
                            <a class="grey-text row centrarcontenido" href="#!">
                                <label class="truncate">
                                    <span class="glyphicon glyphicon-user"></span><?php echo e(Auth::user()->nombres.' '.Auth::user()->apellidos); ?>

                                </label>
                            </a>
                        </li>
                        <li>
                            <notifications-dropdown></notifications-dropdown>
                        </li>
                        <li>
                            <a href="#" style="display: block" data-activates="slide-out"
                               class="button-collapse grey-text"><i
                                        class="glyphicon glyphicon-cog" aria-hidden="true"></i></a>
                            <ul id="slide-out" class="side-nav">
                                <li>
                                    <div class="userView">
                                        <div class="background">
                                            <img src="<?php echo e(asset('img/banner01.jpg')); ?>"
                                                 style="width:100%;heigth:100%;">
                                        </div>
                                        <a href="#!user"><img class="circle"
                                                              src="<?php echo e(asset(\Illuminate\Support\Facades\Auth::user()->imagen)); ?>"></a>
                                        <a href="#!name"><span
                                                    class="black-text name"><?php echo e(\Illuminate\Support\Facades\Auth::user()->usuario); ?></span></a>
                                        <a href="#!email"><span
                                                    class="black-text email"><?php echo e(\Illuminate\Support\Facades\Auth::user()->email); ?></span></a>
                                    </div>
                                </li>
                                <li><a href="#!"><i class="material-icons">add_alert</i>Notificaciones</a></li>
                                <li>
                                    <notifications-demo></notifications-demo>
                                </li>
                                <li>
                                    <div class="divider"></div>
                                </li>
                                <li><a class="subheader">Configuraciones</a></li>
                                <li><a href="<?php echo e(url('logout')); ?>"
                                       class="waves-effect">Salir</a></li>
                            </ul>
                        </li>
                    <?php else: ?>
                        <li>
                            <a href="<?php echo e(route('login')); ?>" class="white-text"><span class="green"
                                                                                  style="border-radius: 4px">Ingresar</span></a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('register',['type'=>0])); ?>" class="white-text"><span class="green"
                                                                                                 style="border-radius: 4px">Registrarme</span></a>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>
    <?php echo $__env->yieldContent('content'); ?>
</div>
<div class="preloader-background" id="cargando">
    <div class="preloader-wrapper big active" id="cuerpocargando">
        <div class="spinner-layer spinner-blue">
            <div class="circle-clipper left">
                <div class="circle"></div>
            </div>
            <div class="gap-patch">
                <div class="circle"></div>
            </div>
            <div class="circle-clipper right">
                <div class="circle"></div>
            </div>
        </div>

        <div class="spinner-layer spinner-red">
            <div class="circle-clipper left">
                <div class="circle"></div>
            </div>
            <div class="gap-patch">
                <div class="circle"></div>
            </div>
            <div class="circle-clipper right">
                <div class="circle"></div>
            </div>
        </div>

        <div class="spinner-layer spinner-yellow">
            <div class="circle-clipper left">
                <div class="circle"></div>
            </div>
            <div class="gap-patch">
                <div class="circle"></div>
            </div>
            <div class="circle-clipper right">
                <div class="circle"></div>
            </div>
        </div>

        <div class="spinner-layer spinner-green">
            <div class="circle-clipper left">
                <div class="circle"></div>
            </div>
            <div class="gap-patch">
                <div class="circle"></div>
            </div>
            <div class="circle-clipper right">
                <div class="circle"></div>
            </div>
        </div>
    </div>
</div>
<!-- modal -->
<div id="eliminardato" class="modal fade" role="dialog">
    <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close"
                        data-dismiss="modal">&times;</button>
                <h4 class="modal-title tituloeliminardato blue-text">Modal
                    Header</h4>
            </div>
            <div class="modal-body">
                <p class="textoelimardato red-text"></p>
            </div>
            <div class="modal-footer">

                <button type="button" id="cancelareliminar"
                        class="btn btn-default light-blue light-green"
                        data-dismiss="modal">
                    Cancelar
                </button>
                <button type="button"
                        class="btn btn-default light-blue red botoneliminardato">
                    Eliminar
                </button>
            </div>
        </div>

    </div>
</div>

<!-- Scripts -->

<script src="<?php echo e(mix('js/appprincipalall.js')); ?>"></script>
<script src="<?php echo e(mix('js/app.js')); ?>"></script>

<!--Import jQuery before materialize.js-->
<script type="text/javascript" src="<?php echo e(asset('js/materialize.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/jqueryui.js')); ?>"></script>
<script src="<?php echo e(asset('js/select2.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/es.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery.validate.min.js')); ?>"></script>
<script src="<?php echo e(mix('js/funcionesgeneralesall.js')); ?>"></script>
<script src="<?php echo e(asset('js/timeago.js')); ?>"></script>
<?php if(url()->current()==url('inventario.verinventario') || url()->current()==url('doperacionesprincipal') || url()->current()==url('doperaciones.consultar')): ?>
    <script type="text/javascript" src="<?php echo e(asset('js/jquery.dataTables.min.js')); ?>"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/1.10.15/js/dataTables.semanticui.min.js"></script>
    <script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.2.6/semantic.min.js"></script>
<?php endif; ?>
<?php echo $__env->yieldContent('script'); ?>
<!--<script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/additional-methods.min.js"></script>-->

<footer class="page-footer">
    <div class="container">
        <div class="row">
            <div class="col l6 s12">
                <h5 class="white-text">Footer Content</h5>
                <p class="grey-text text-lighten-4">You can use rows and columns here to organize your footer
                    content.</p>
            </div>
            <div class="col l4 offset-l2 s12">
                <h5 class="white-text">Links</h5>
                <ul>
                    <li><a class="grey-text text-lighten-3" href="#!">Link 1</a></li>
                    <li><a class="grey-text text-lighten-3" href="#!">Link 2</a></li>
                    <li><a class="grey-text text-lighten-3" href="#!">Link 3</a></li>
                    <li><a class="grey-text text-lighten-3" href="#!">Link 4</a></li>
                </ul>
            </div>
        </div>
    </div>
    <div class="footer-copyright">
        <div class="container">
            © WILLITAD TICS S.A.S
            <a class="grey-text text-lighten-4 right" href="www.willitad.com" target="_blank">© WILLITAD TICS S.A.S</a>
        </div>
    </div>
</footer>
</body>
</html>
