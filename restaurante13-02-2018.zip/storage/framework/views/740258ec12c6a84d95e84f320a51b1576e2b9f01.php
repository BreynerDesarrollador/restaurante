<?php
/**
 * Created by PhpStorm.
 * User: windows 8.1
 * Date: 16/11/2017
 * Time: 11:25 AM
 */
$op = \Illuminate\Support\Facades\Session::get('op');
?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="right">
            <button class="btn light light-green nuevousuario" data-toggle="modal" data-target="#nuevousuario">
                <span class="glyphicon glyphicon-plus-sign"></span>Crear usuarios
            </button>
            <button style="display: none" class="btn light light-green nuevousuario1" data-toggle="modal"
                    data-target="#nuevousuario">
                <span class="glyphicon glyphicon-plus-sign"></span>Crear usuarios
            </button>
        </div>
        <table id="tableinventario" class="ui celled table table-responsive" cellspacing="0"
               width="100%">
            <thead>
            <tr>
                <th>
                    Nombres
                </th>
                <th>
                    Apellidos
                </th>
                <th>
                    E-mail
                </th>
                <th>
                    Tipo
                </th>
                <th>
                    Gestionar
                </th>
            </tr>
            </thead>
            <tfoot>
            <tr>
                <th>
                    Nombres
                </th>
                <th>
                    Apellidos
                </th>
                <th>
                    E-mail
                </th>
                <th>
                    Tipo
                </th>
                <th>
                    Gestionar
                </th>
            </tr>
            </tfoot>
            <tbody>
            <?php $__currentLoopData = $datos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                        <?php echo e($item->nombres); ?>

                    </td>
                    <td>
                        <?php echo e($item->apellidos); ?>

                    </td>
                    <td>
                        <?php echo e($item->email); ?>

                    </td>
                    <td>
                        <?php echo e($item->typenombre); ?>

                    </td>
                    <td>
                        <input type="hidden" id="datosusuarios<?php echo e($item->id); ?>" name="datosusuarios<?php echo e($item->id); ?>"
                               value="<?php echo e(collect($item)); ?>">
                        <a href="#!" class="aeditarusuario" value="<?php echo e($item->id); ?>"><span
                                    class="glyphicon glyphicon-edit"></span></a>
                        <a href="#!" class="aeliminarusuario" value="<?php echo e($item->id); ?>"><span
                                    class="glyphicon glyphicon-remove-circle red-text"></span></a>
                        <form action="<?php echo e(url('/usuarios.eliminarusuario/'.$item->id)); ?>" method="POST"
                              id="eliminarusuario<?php echo e($item->id); ?>">
                            <?php echo e(method_field('DELETE')); ?>

                            <?php echo e(csrf_field()); ?>

                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <div class="modal fade" id="nuevousuario" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
         aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title center">Gestionar usuarios</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="<?php echo e(url("usuarios.guardarusuario")); ?>" method="post" id="formguardarusuario" role="form"
                          novalidate>
                        <?php echo e(csrf_field()); ?>

                        <?php if($errors->any()): ?>
                            <div class="alert alert-danger">
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                        <input type="hidden" id="operacion" name="operacion" value="guardarproducto">
                        <div class="row">
                            <div class="input-field col s12 m6 l6">
                                <input required data-toggle="popover" data-trigger="" data-placement="top"
                                       title="campo obligatorio"
                                       data-content="Corresponde al nombre del usuario..."
                                       name="nombres" id="nombres" type="text" value="<?php echo e(old('nombres')); ?>"
                                       placeholder="Ej: Andres">
                                <label class="active" for="nombres">Nombres:</label>
                            </div>
                            <div class="input-field col s12 m6 l6">
                                <input name="apellidos" id="apellidos" type="text" data-toggle="popover"
                                       data-placement="top" data-trigger="" title="Precio" required
                                       value="<?php echo e(old('apellidos')); ?>" placeholder="apellidos"
                                       data-content="Corresponde al apellido del usuario...">
                                <label class="active" for="apellidos">Apellidos:</label>
                            </div>
                            <div class="input-field col s12 m6 l6">
                                <input name="email" id="email" type="email" placeholder="Ej: example@dominio.com"
                                       data-toggle="popover"
                                       data-placement="top" data-trigger="" title="Email" required
                                       value="<?php echo e(old('email')); ?>"
                                       data-content="Corresponde al correo electronico del usuario...">
                                <label class="active" for="email">E-mail:</label>
                            </div>
                            <div class="input-field col s12 m6 l6">
                                <input name="password" id="password" type="password" data-toggle="popover"
                                       data-placement="top" data-trigger="" title="password" required
                                       data-content="La contraseña debe tener como minimo 8 caracteres, para mas seguridad se recomienda letras y números...">
                                <label class="active" for="password">Contraseña:</label>
                            </div>
                            <div class="input-field col s12 m6 l6">
                                <label for="type" class="active">Tipo de usuario:</label>
                                <select data-minimum-results-for-search="Infinity" id="type"
                                        data-toggle="popover" data-placement="top" data-trigger="" title="Precio"
                                        data-content="Corresponde a la clasificación del producto, ej: Verduras, frutas, aceites, etc."
                                        name="type" aria-required="true"
                                        class="required">
                                    <option value="">Seleccione...</option>
                                    <option value="1">Caja</option>
                                    <option value="2">Cocina</option>
                                    <option value="3">Mesero</option>
                                </select>
                            </div>
                        </div>
                        <div class="row center">
                            <button type="submit" class="btn btn-primary light light-blue"><span
                                        class="glyphicon glyphicon-floppy-save guardarproducto"></span>Guardar
                            </button>
                        </div>
                    </form>
                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary light light-green" data-dismiss="modal"><span
                                class="glyphicon glyphicon-eye-close"></span> Cancelar
                    </button>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection("script"); ?>
    <script>
        $(document).ready(function () {
            cargarcomboselectnormal("#type");
            validarformulario('formguardarusuario', {
                nombres: "required",
                apellidos: "required",
                email: "required",
                password: "required",
                type: "required"
            });
            $(".aeliminarusuario").click(function () {
                valor = $(this).attr('value');
                $("#eliminarusuario" + valor).submit();
            });
            $(".nuevousuario").click(function () {
                //location.href = "/usuarios?op=nuevousuario";
            });
            $(".aeditarusuario").click(function () {
                valor = $(this).attr("value");
                datos = JSON.parse($("#datosusuarios" + valor).val());
                form = $("#formguardarusuario");
                $(form).find("#nombres").val(datos.nombres);
                $(form).find("#apellidos").val(datos.apellidos);
                $(form).find("#email").val(datos.email);
                $(form).find("#type").val(datos.type).trigger("change");
                $(form).attr("action", '/usuarios.editarusuario/' + valor);
                $("#password").rules("remove");
                $("#password").removeAttr("required");
                $(".nuevousuario1").click();
            });
            <?php if(!empty(session('op'))): ?>
            $(".nuevousuario1").click();
            <?php endif; ?>
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>