<?php
/**
 * Created by PhpStorm.
 * User: windows 8.1
 * Date: 23/01/2018
 * Time: 5:37 PM
 */
?>

<?php $__env->startSection('content'); ?>
    <div class="col s12 m12 l12">
        <?php if(session()->get('cliente')): ?>
            <?php if(!\Illuminate\Support\Facades\Auth::check()): ?>
                <div class="container">
                    <h5>
                        <p>Para ingresar es necesario registrarse o iniciar sesión mediante tus redes sociales,
                            gracias por utilizar nuestro portal web.</p>
                        <a href="#!">Policticas de seguridad</a>
                    </h5>
                <!-- <a class="btn btn-block btn-social btn-instagram" href="<?php echo e(route('social.auth', 'instagram')); ?>">
            <span class="fa fa-twitter"></span>Iniciar sesión con Instagram
        </a><br>-->
                    <a class="btn btn-block btn-social btn-facebook" href="<?php echo e(route('social.auth', 'facebook')); ?>">
                        <span class="fa fa-facebook"></span>Iniciar sesión Facebook
                    </a><br>
                    <a class="btn btn-block btn-social btn-google" href="<?php echo e(route('social.auth', 'google')); ?>">
                        <span class="fa fa-google"></span>Iniciar sesión con Google
                    </a>
                    <a class="btn btn-block btn-social light light-blue" href="<?php echo e(url('clientesalir')); ?>">
                        <span class="material-icons">close</span>Cancelar
                    </a>
                </div>
            <?php else: ?>
                <?php if(\Illuminate\Support\Facades\Auth::user()->type==6): ?>
                    <?php
                        $menus=[];
                        $usuario=\Illuminate\Support\Facades\Auth::user()->user;
                        $menus=DB::select("call sp_infoplatomenu('infomenu',$usuario,'');");
                    ?>
                    <cliente-pedido :datoscliente="<?php echo e(collect(session()->get('cliente'))); ?>"
                                    :datosmenus1="<?php echo e(collect($menus)); ?>"></cliente-pedido>
                <?php endif; ?>
            <?php endif; ?>
        <?php else: ?>
            <div class="container center">
                <h3 id="mensajeescanear">Por favor escanee el codigo QR de la mesa, recuerde no mover mucho su celular,
                    para
                    una mayor lectura, recuerde permitir acceder a su camara para poder escanear el codigo QR.</h3>
                <h1>
                    <span class="glyphicon glyphicon-qrcode"></span>
                </h1>
                <video id="preview" style="width: 400px;height: 400px"></video>
            </div>
        <?php $__env->startSection('script'); ?>
            <script src="<?php echo e(mix('js/instascanall.js')); ?>"></script>
            <script async src="<?php echo e(asset('js/escaner.js')); ?>"></script>

        <?php $__env->stopSection(); ?>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.cliente', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>