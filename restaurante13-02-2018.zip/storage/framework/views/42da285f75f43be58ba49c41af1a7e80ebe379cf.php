<?php
/**
 * Created by PhpStorm.
 * User: windows 8.1
 * Date: 08/11/2017
 * Time: 2:21 PM
 */
?>

<?php $__env->startSection('content'); ?>
    <link rel="stylesheet" type="text/css" href="//cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.2.6/semantic.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.15/css/dataTables.semanticui.min.css">
    <div class="container">
        <div class="col s12 m12 l12 right">
            <?php echo e($datos->links()); ?>

        </div>
        <table id="tableinventario" class="ui celled table table-responsive" cellspacing="0"
               width="100%">
            <thead>
            <tr>
                <th>
                    Producto
                </th>
                <th>
                    Precio
                </th>
                <th>
                    Importe
                </th>
                <th>
                    Medida
                </th>
                <th>
                    Inventario
                </th>
                <th>
                    Total
                </th>
            </tr>
            </thead>
            <tfoot>
            <tr>
                <th>
                    Producto
                </th>
                <th>
                    Precio
                </th>
                <th>
                    Importe
                </th>
                <th>
                    Medida
                </th>
                <th>
                    Inventario
                </th>
                <th>
                    Total
                </th>
            </tr>
            </tfoot>
            <tbody>
            <?php $__currentLoopData = $datos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr data-toggle="popover" data-trigger="hover" data-placement="top"
                    title="Estado del producto"
                    data-content="<?php if($item->estado=='bajo'): ?> Actualmente este producto se encuentra en esta bajo, <?php elseif($item->estado=='medio'): ?> Actualmente este producto se encuentra en estado medio,  <?php else: ?> Actualmente se encuentra en estado normal, <?php endif; ?> recuerde mirar el inventario de sus productos."
                    class="<?php if($item->estado=='bajo'): ?> red white-text <?php endif; ?> "
                    style="<?php if($item->estado=='medio'): ?>background-color: yellow;color: black!important; <?php endif; ?> ">
                    <td>
                        <?php echo e($item->producto); ?>

                    </td>
                    <td>
                        <?php echo e($item->precio); ?>

                    </td>
                    <td>
                        <?php echo e($item->importe); ?>

                    </td>
                    <td>
                        <?php echo e($item->medida); ?>

                    </td>
                    <td>
                        <?php echo e($item->inventario); ?>

                    </td>
                    <td>
                        <?php echo e($item->total); ?>

                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
        $(document).ready(function () {
            $("#tableinventario").DataTable({
                'language': {
                    "sProcessing": "Procesando...",
                    "sLengthMenu": "Mostrar _MENU_ registros",
                    "sZeroRecords": "No se encontraron resultados",
                    "sEmptyTable": "Ningún dato disponible en esta tabla",
                    "sInfo": "Mostrando registros del _START_ al _END_ de un total de _TOTAL_ registros",
                    "sInfoEmpty": "Mostrando registros del 0 al 0 de un total de 0 registros",
                    "sInfoFiltered": "(filtrado de un total de _MAX_ registros)",
                    "sInfoPostFix": "",
                    "sSearch": "Buscar:",
                    "sUrl": "",
                    "sInfoThousands": ",",
                    "sLoadingRecords": "Cargando...",
                    "oPaginate": {
                        "sFirst": "Primero",
                        "sLast": "Último",
                        "sNext": "Siguiente",
                        "sPrevious": "Anterior"
                    },
                    "oAria": {
                        "sSortAscending": ": Activar para ordenar la columna de manera ascendente",
                        "sSortDescending": ": Activar para ordenar la columna de manera descendente"
                    }
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>