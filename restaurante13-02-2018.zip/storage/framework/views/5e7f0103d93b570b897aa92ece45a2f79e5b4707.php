<?php
/**
 * Created by PhpStorm.
 * User: windows 8.1
 * Date: 27/10/2017
 * Time: 4:06 PM
 */
?>

<?php $__env->startSection('content'); ?>
    <div class="row">

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>