<?php
/**
 * Created by PhpStorm.
 * User: windows 8.1
 * Date: 24/01/2018
 * Time: 9:53 AM
 */
?>
        <!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Laravel</title>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <!--Import materialize.css-->
    <link  rel="stylesheet" href="<?php echo e(asset('css/materialize.min.css')); ?>" media="screen,projection"/>
    <link  rel="stylesheet" href="<?php echo e(mix('css/app.css')); ?>"/>
    <link  rel="stylesheet" href="<?php echo e(asset('css/bootstrapsocial.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/styleapp.css')); ?>">
    <link  rel="stylesheet" href="<?php echo e(asset('css/fontawesome.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    <meta name="description" content="Plataforma de gestión para restaurantes">
    <meta name="keywords" content="restautante, bar, etc...">
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <!-- Styles -->
    <script>
        window.Laravel = <?php echo json_encode([
            'user' => Auth::user(),
            'csrfToken' => csrf_token(),
            'vapidPublicKey' => config('webpush.vapid.public_key'),
            'pusher' => [
                'key' => config('broadcasting.connections.pusher.key'),
                'cluster' => config('broadcasting.connections.pusher.options.cluster'),
            ],
        ]); ?>;
        window.appopcion = {
            op: 'mesas'
        }
    </script>
    <script src="<?php echo e(asset('js/jquery.js')); ?>"></script>
</head>
<body class="form-horizontal">
<div id="app" v-cloak>
<?php if(\Illuminate\Support\Facades\Auth::check()): ?>
    <!-- Horizonal Navigation bar -->
        <nav class="navbar nav-fixed white">
            <div class="nav-wrapper">
                <a href="#" data-activates="mobile-demo" class="button-collapse"><i class="material-icons">menu</i></a></a>
                <a id="logo-container" class="brand-logo">
                    <img height="50" width="50" src="<?php echo e(\Illuminate\Support\Facades\Auth::user()->imagen); ?>"
                         class="img-circle">
                </a>
                <!-- Horizontal Navbar links only shown on large resolutions -->
                <ul class="right hide-on-med-and-down">
                    <li>
                        <a href="#!">
                            <h5><?php echo e(\Illuminate\Support\Facades\Auth::user()->nombres); ?></h5>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(url('clientesalir')); ?>">
                            <h5><span class="glyphicon glyphicon-arrow-right"></span>Salir</h5>
                        </a>
                    </li>
                </ul>
                <ul id="mobile-demo" class="side-nav">
                    <li><a href="#!"><?php echo e(\Illuminate\Support\Facades\Auth::user()->nombres); ?></a></li>
                    <li><a href="<?php echo e(url('clientesalir')); ?>"><span class="glyphicon glyphicon-arrow-right"></span>Salir</a>
                    </li>
                </ul>
            </div>
        </nav>
    <?php endif; ?>
    <?php echo $__env->yieldContent('content'); ?>
</div>
<div class="preloader-background" id="cargando">
    <div class="preloader-wrapper big active" id="cuerpocargando">
        <div class="spinner-layer spinner-blue">
            <div class="circle-clipper left">
                <div class="circle"></div>
            </div>
            <div class="gap-patch">
                <div class="circle"></div>
            </div>
            <div class="circle-clipper right">
                <div class="circle"></div>
            </div>
        </div>

        <div class="spinner-layer spinner-red">
            <div class="circle-clipper left">
                <div class="circle"></div>
            </div>
            <div class="gap-patch">
                <div class="circle"></div>
            </div>
            <div class="circle-clipper right">
                <div class="circle"></div>
            </div>
        </div>

        <div class="spinner-layer spinner-yellow">
            <div class="circle-clipper left">
                <div class="circle"></div>
            </div>
            <div class="gap-patch">
                <div class="circle"></div>
            </div>
            <div class="circle-clipper right">
                <div class="circle"></div>
            </div>
        </div>

        <div class="spinner-layer spinner-green">
            <div class="circle-clipper left">
                <div class="circle"></div>
            </div>
            <div class="gap-patch">
                <div class="circle"></div>
            </div>
            <div class="circle-clipper right">
                <div class="circle"></div>
            </div>
        </div>
    </div>
</div>
<script src="<?php echo e(asset('js/clientepedido.js')); ?>"></script>
<script src="<?php echo e(mix('js/app.js')); ?>"></script>
<script src="<?php echo e(asset('js/materialize.min.js')); ?>"></script>
<script type="text/javascript">
    $(document).ready(function () {
        $(".button-collapse").sideNav();
    });
</script>
<?php echo $__env->yieldContent('script'); ?>
</body>
</html>


