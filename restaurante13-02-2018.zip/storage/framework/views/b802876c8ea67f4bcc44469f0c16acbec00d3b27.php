<?php
/**
 * Created by PhpStorm.
 * User: windows 8.1
 * Date: 16/11/2017
 * Time: 4:36 PM
 */
$opcion = \Illuminate\Support\Facades\Input::get('op');
$user = \Illuminate\Support\Facades\Auth::user()->type;
$mesas = [];
$menus = [];
$usuario = \Illuminate\Support\Facades\Auth::user()->user;
?>

<?php $__env->startSection("content"); ?>
    <link href="<?php echo e(asset('css/platos.css')); ?>" rel="stylesheet">
    <?php if($user==3): ?>
        <?php
            $mesas=DB::select("call sp_listarmesas($usuario);");
            $menus=DB::select("call sp_infoplatomenu('infomenu',$usuario,'');");
        ?>
        <menu-platos :datosmenus1="<?php echo e(collect($menus)); ?>" :datosmesas1="<?php echo e(collect($mesas)); ?>"></menu-platos>
    <?php elseif($user==2): ?>
        <cocina-home></cocina-home>
    <?php elseif($user==1): ?>
        <caja></caja>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>