<?php
/**
 * Created by PhpStorm.
 * User: windows 8.1
 * Date: 23/01/2018
 * Time: 5:37 PM
 */
?>
@extends('layouts.cliente')
@section('content')
    <div class="col s12 m12 l12">
        @if(session()->get('cliente'))
            @if(!\Illuminate\Support\Facades\Auth::check())
                <div class="container">
                    <h5>
                        <p>Para ingresar es necesario registrarse o iniciar sesión mediante tus redes sociales,
                            gracias por utilizar nuestro portal web.</p>
                        <a href="#!">Policticas de seguridad</a>
                    </h5>
                <!-- <a class="btn btn-block btn-social btn-instagram" href="{{ route('social.auth', 'instagram') }}">
            <span class="fa fa-twitter"></span>Iniciar sesión con Instagram
        </a><br>-->
                    <a class="btn btn-block btn-social btn-facebook" href="{{ route('social.auth', 'facebook') }}">
                        <span class="fa fa-facebook"></span>Iniciar sesión Facebook
                    </a><br>
                    <a class="btn btn-block btn-social btn-google" href="{{ route('social.auth', 'google') }}">
                        <span class="fa fa-google"></span>Iniciar sesión con Google
                    </a>
                    <a class="btn btn-block btn-social light light-blue" href="{{url('clientesalir')}}">
                        <span class="material-icons">close</span>Cancelar
                    </a>
                </div>
            @else
                @if(\Illuminate\Support\Facades\Auth::user()->type==6)
                    @php
                        $menus=[];
                        $usuario=\Illuminate\Support\Facades\Auth::user()->user;
                        $menus=DB::select("call sp_infoplatomenu('infomenu',$usuario,'');");
                    @endphp
                    <cliente-pedido :datoscliente="{{collect(session()->get('cliente'))}}"
                                    :datosmenus1="{{collect($menus)}}"></cliente-pedido>
                @endif
            @endif
        @else
            <div class="container center">
                <h3 id="mensajeescanear">Por favor escanee el codigo QR de la mesa, recuerde no mover mucho su celular,
                    para
                    una mayor lectura, recuerde permitir acceder a su camara para poder escanear el codigo QR.</h3>
                <h1>
                    <span class="glyphicon glyphicon-qrcode"></span>
                </h1>
                <video id="preview" style="width: 400px;height: 400px"></video>
            </div>
        @section('script')
            <script src="{{mix('js/instascanall.js')}}"></script>
            <script async src="{{asset('js/escaner.js')}}"></script>

        @endsection
        @endif
    </div>
@endsection