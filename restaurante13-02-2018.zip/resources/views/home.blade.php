@extends('layouts.app')
@section('content')
    <div class="content" id="divhome">
        <div class="container wow fadeInUp delay-03s">
            <div class="row">
                <div class="logo center">
                    <i class="material-icons white-text medium">person</i>
                    <h2 class="teal">Gestiona tus inventarios de tu restaurante o bar, de manera facil y eficiente</h2>
                    <div class="divgestionar">
                        <a href="#!" class="btn light teal btn-info btn-lg" onclick="mostrarocultar('registrar')"><span class="glyphicon glyphicon-new-window"></span>Registrarme</a>
                        <a href="#!" class="btn light teal btn-info btn-lg" onclick="mostrarocultar('login')"><span class="glyphicon glyphicon-user"></span>Ingresar</a>
                        <a href="/cliente" class="btn light teal btn-info btn-lg"><span class="glyphicon glyphicon-qrcode"></span>Qr code cliente</a>
                    </div>
                    <div id="divregistrarme" style="display:@if(session('register'))  block @else none @endif">
                        @include('auth.register')
                    </div>
                    <div id="divlogin" style="display:@if($errors->any())  block @else none @endif">
                        @include('auth.login')
                    </div>
                </div>
            </div>
        </div>
        <section>
            <div class="container">
                <div class="row bort text-center">
                    <div class="social">
                        <ul>
                            <li>
                                <a href=""><i class="fa fa-facebook"></i></a>
                            </li>
                            <li>
                                <a href=""><i class="fa fa-twitter"></i></a>
                            </li>
                            <!--<li>
                                <a href=""><i class="fa fa-linkedin"></i></a>
                            </li> -->
                        </ul>
                    </div>
                </div>
            </div>
        </section>
        <section id="about" class="section-padding">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 col-sm-12 text-center">
                        <div class="about-title">
                            <h2>Sobre restaurante</h2>
                            <p>Restaurante es una plataforma que te ayudara a gestionar tus inventarios de manera facil,
                                eficaz y organizada.
                                </br>Te muestra todos los gastos, estadisticas y graficos de tus inventarios, semanal o
                                mensual</p>
                        </div>
                        <div class="col-md-3 col-sm-6 col-xs-12 wow fadeInUp delay-02s">
                            <div class="img">
                                <i class="fa fa-refresh"></i>
                            </div>
                            <h3 class="abt-hd">Procesos</h3>
                            <p>Es una plataforma escalable, senciall, y eficiente</p>
                        </div>
                        <div class="col-md-3 col-sm-6 col-xs-12 wow fadeInUp delay-04s">
                            <div class="img">
                                <i class="fa fa-eye"></i>
                            </div>
                            <h3 class="abt-hd">Diseño</h3>
                            <p>Cuenta con graficos y diseño ajustado a las nuevas tecnologías.</p>
                        </div>
                        <div class="col-md-3 col-sm-6 col-xs-12 wow fadeInUp delay-06s">
                            <div class="img">
                                <i class="fa fa-cogs"></i>
                            </div>
                            <h3 class="abt-hd">Configurable</h3>
                            <p>Puedes hacer diferentes configuraciones de acuerdo a tus necesidades.</p>
                        </div>
                        <div class="col-md-3 col-sm-6 col-xs-12 wow fadeInUp delay-08s">
                            <div class="img">
                                <i class="fa fa-dot-circle-o"></i>
                            </div>
                            <h3 class="abt-hd">Nuestro Objetivo</h3>
                            <p>Brindarle a los usuarios finales, control financiero de sus productos y estabilidad en
                                sus negocios.</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <div id="contact-info">
            <div class="container">
                <div class="row">
                    <div class="col-md-6">
                        <div class="contact-title">
                            <i class="fa fa-envelope"></i>
                            <h2>Porque tus opiniones o sugerencias nos importan.</h2>
                            <p>Escribenos o envianos tus sugerencias o inquietudes,<br>con mucho gusto estaremos atento.
                            </p>
                        </div>
                    </div>
                    <div class="contact col-md-6 wow fadeIn delay-08s">
                        <div class="col-md-10 col-md-offset-1">
                            <div id="note"></div>
                            <div id="sendmessage">Su mensaje se ha enviado con exito, gracias por sus sugerencias o
                                comentarios.
                                Si quiere ver nuestros servicios ingrese a <a href="http://willitad.com" target="_blank">WILLITAD TICS
                                    S.A.S</a></div>
                            <div id="errormessage"></div>
                            <form action="{{url('enviarcorreosugerencia')}}" method="post" role="form"
                                  class="contactForm">
                                {{csrf_field()}}
                                <div class="form-group">
                                    <input type="text" name="name" class="form-control" id="name" required
                                           placeholder="Nombre de contacto" data-rule="minlen:4"
                                           data-msg="Please enter at least 4 chars"/>
                                    <div class="validation"></div>
                                </div>
                                <div class="form-group">
                                    <input type="email" class="form-control" name="emailcontacto" id="emailcontacto"
                                           required
                                           placeholder="Email de contacto" data-rule="email"
                                           data-msg="Please enter a valid email"/>
                                    <div class="validation"></div>
                                </div>
                                <div class="form-group">
                                    <input type="text" class="form-control" name="subject" id="subject" required
                                           placeholder="Asunto" data-rule="minlen:4"
                                           data-msg="Please enter at least 8 chars of subject"/>
                                    <div class="validation"></div>
                                </div>
                                <div class="form-group">
                                    <textarea class="form-control" name="message" rows="5" data-rule="required" required
                                              data-msg="Please write something for us"
                                              placeholder="Digite su mensaje"></textarea>
                                    <div class="validation"></div>
                                </div>

                                <div class="text-center">
                                    <button type="submit" class="contact-submit">Enviar mensaje</button>
                                </div>
                                @if(\Illuminate\Support\Facades\Session::has('mensaje'))
                                    <script type="text/javascript">
                                        $(document).ready(function () {
                                            Materialize.toast("{{\Illuminate\Support\Facades\Session::get('mensaje')}}", 4000);
                                            $("#sendmessage").show('slow');
                                        });
                                    </script>
                                @endif
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <footer class="footer">
        <div class="container">
            <div class="row bort">

                <div class="copyright">
                    © WILLITAD TICS S.A.S
                    <div class="credits">
                        Empresa de desarrollo <a href="http://willitad.com/">Willitad tics s.a.s</a>
                    </div>
                </div>

            </div>
        </div>
    </footer>
@endsection
