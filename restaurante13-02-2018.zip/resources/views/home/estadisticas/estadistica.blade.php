<?php
/**
 * Created by PhpStorm.
 * User: windows 8.1
 * Date: 15/11/2017
 * Time: 11:52 AM
 */
?>
@extends('layouts.app')
@section('content')
    <div class="row">
        <fieldset class="container">
            <legend>Tipo de estadistica</legend>
            <div class="col s12 m6 l6">
                <select name="estadisticatipo" id="estadisticatipo">
                    <option value="">Seleccione...</option>
                    <option value="inventario">Inventario</option>
                    <option value="producto">Producto</option>
                    <!-- <option value="precio">Precio</option> -->
                </select>
            </div>
            <div class="col s12 m6 l6">
                <select name="estadisticatipofiltro" id="estadisticatipofiltro">
                    <option value="">Seleccione...</option>
                    <option value="semana">Semana</option>
                    <option value="mes">Mes</option>
                    <option value="ano">Año</option>
                    <!-- <option value="precio">Precio</option> -->
                </select>
            </div>
        </fieldset>

        <div class="col s12 m12 l12">
            @foreach(Charts::types($chart->library) as $type)
                {!! $chart->Type($type)->render() !!}
            @endforeach
        </div>

    </div>
@endsection
@section("script")
    <script>
        $(document).ready(function () {
            cargarcomboselectnormal("#estadisticatipo");
            cargarcomboselectnormal("#estadisticatipofiltro");
            $("#estadisticatipo,#estadisticatipofiltro").change(function () {
                valor = $("#estadisticatipo").val();
                valor1 = $("#estadisticatipofiltro").val();
                if (valor != undefined && valor != "" && valor1 != undefined && valor1 != "") {
                    location.href = "/estadisticas?type=" + valor + "&valor=" + valor1;
                }

            });
        });
    </script>
@endsection