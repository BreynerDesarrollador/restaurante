<?php
/**
 * Created by PhpStorm.
 * User: windows 8.1
 * Date: 27/10/2017
 * Time: 4:06 PM
 */
?>
@extends('layouts.app')
@section('content')
    <div class="row">

    </div>
@endsection