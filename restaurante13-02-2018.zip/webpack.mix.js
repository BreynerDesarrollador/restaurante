let mix = require('laravel-mix');

/*
 |--------------------------------------------------------------------------
 | Mix Asset Management
 |--------------------------------------------------------------------------
 |
 | Mix provides a clean, fluent API for defining some Webpack build steps
 | for your Laravel application. By default, we are compiling the Sass
 | file for the application as well as bundling up all the JS files.
 |
 */

mix.js('resources/assets/js/app.js', 'public/js')
   .sass('resources/assets/sass/app.scss', 'public/css');

mix.scripts([
    'public/js/doperaciones.js'
], 'public/js/alldo.js');
mix.scripts([
    'public/js/home.js'
], 'public/js/homeapp.js');
mix.scripts([
    'public/js/appprincipal.js'
], 'public/js/appprincipalall.js');
mix.scripts([
    'public/js/funcionesgenerales.js'
], 'public/js/funcionesgeneralesall.js');
mix.scripts([
    'public/js/instascan.min.js'
], 'public/js/instascanall.js');

if (mix.inProduction()) {
    mix.version();
}